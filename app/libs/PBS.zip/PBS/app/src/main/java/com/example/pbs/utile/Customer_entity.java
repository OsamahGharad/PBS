package com.example.pbs.utile;

public class Customer_entity {
    public String name,address,phone;

    public Customer_entity(String name, String address, String phone) {
        this.name = name;
        this.address = address;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }
}
