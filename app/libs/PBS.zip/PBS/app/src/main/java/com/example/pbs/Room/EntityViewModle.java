package com.example.pbs.Room;

public class EntityViewModle {
}
