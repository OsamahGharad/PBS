package com.example.pbs.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pbs.Activity.MainActivity;
import com.example.pbs.Interface.CallFragment;
import com.example.pbs.Modle.Task;
import com.example.pbs.adapter.TaskAdapter;
import com.example.pbs.R;


import java.util.ArrayList;

public class salesInvoice extends Fragment {
    RecyclerView recyclerView;
    TaskAdapter taskAdapter;
    Toolbar toolbar;
    ArrayList<Task> examples;
    static CallFragment callFragment;
    private static salesInvoice instance;


    public  static  salesInvoice getInstance(){
        if(instance==null)
        {
            instance=new salesInvoice();
        }
        return instance;
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         examples=new ArrayList<>();
        examples.add(new Task(getString(R.string.sales_invoice)+"0","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"1","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"2","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"3","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"4","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"5","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"6","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"7","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"8","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"0","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"1","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"2","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"3","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"4","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"5","12/4/2020",R.drawable.more_vert_black));
         examples.add(new Task(getString(R.string.sales_invoice)+"0","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"1","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"2","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"3","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"4","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"5","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"6","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"7","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"8","12/4/2020",R.drawable.more_vert_black));

        examples.add(new Task(getString(R.string.sales_invoice)+"7","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"8","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"0","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"1","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"2","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"3","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"4","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"5","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"6","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"7","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.sales_invoice)+"8","12/4/2020",R.drawable.more_vert_black));

        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.sales_invoice, null);
        toolbar=((MainActivity)this.getActivity()).getToolbar();
        toolbar.setTitle(getString(R.string.sales_invoice));
        toolbar.setNavigationIcon(R.drawable.arrow_forward);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();


            }
        });
        recyclerView=view.findViewById(R.id.sales_invoice_recycleView);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        taskAdapter=new TaskAdapter(examples);
        recyclerView.setAdapter(taskAdapter);
       taskAdapter.SetOnItemClickListener(new TaskAdapter.OnItemClickListrner() {
            @Override
            public void OnItemClick(int position) {
               callFragment.call_fragment_method(new ERBInvoice() );
            }
        });

        return view;
    }
    public void setCallFragments(CallFragment callFragment)
    {
        this.callFragment = callFragment;
    }


    }

