package com.example.pbs.Modle;

public class Task {
    private String Name,Dates;
    private int image;

    public Task(String name, String dates, int mimageResource) {
        Name = name;
        Dates = dates;
        image = mimageResource;
    }

    public String getName() {
        return Name;
    }

    public String getDates() {
        return Dates;
    }

    public int getImage() {
        return image;
    }
}
