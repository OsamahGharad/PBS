package com.example.pbs.Fragment;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.pbs.Activity.MainActivity;
import com.example.pbs.Interface.CallFragment;
import com.example.pbs.Modle.Task;
import com.example.pbs.R;
import com.example.pbs.adapter.TaskAdapter;

import java.util.ArrayList;


public class Tasks extends Fragment {

    RecyclerView recyclerView;
    ArrayList<Task> examples;
    Toolbar toolbar;
    static CallFragment callFragment;
    @Override
    public void onAttach(Context context) {super.onAttach(context);
        setHasOptionsMenu(true);
    }
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        examples=new ArrayList<>();
        examples.add(new Task(getString(R.string.task_name)+"1","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"2","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"3","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"4","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"5","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"6","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"7","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"8","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"9","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"10","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"11","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"12","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"13","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"1","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"2","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"3","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"4","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"5","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"6","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"7","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"8","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"9","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"10","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"11","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"12","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"13","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"1","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"2","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"3","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"4","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"5","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"6","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"7","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"8","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"9","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"10","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"11","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"12","12/4/2020",R.drawable.more_vert_black));
        examples.add(new Task(getString(R.string.task_name)+"13","12/4/2020",R.drawable.more_vert_black));


    }


    public void setCallFragments(CallFragment callFragment) {
        this.callFragment = callFragment;




    }
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.tasks, null);
        toolbar=((MainActivity)this.getActivity()).getToolbar();
        toolbar.setTitle(getString(R.string.menu_tasks));
        toolbar.setNavigationIcon(R.drawable.arrow_forward);

        toolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
        getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR);
        recyclerView=view.findViewById(R.id.task_recycleView);
        RecyclerView.LayoutManager layoutManager=new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        TaskAdapter taskAdapter=new TaskAdapter(examples);
        recyclerView.setAdapter(taskAdapter);
        taskAdapter.SetOnItemClickListener(new TaskAdapter.OnItemClickListrner() {
            @Override
            public void OnItemClick(int position) {
                callFragment.call_fragment_method(new TaskNumber());

            }
        });

        return  view;

    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
           getActivity().getMenuInflater().inflate(R.menu.mainactionbar, menu);
           MenuItem item =menu.findItem(R.id.indebt_invoice);
           item.setVisible(false);


    }






}
