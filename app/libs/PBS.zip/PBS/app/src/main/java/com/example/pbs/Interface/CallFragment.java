package com.example.pbs.Interface;

import androidx.fragment.app.Fragment;

public interface CallFragment {
    public void call_fragment_method(Fragment fragment);
}
